package com.missionbreak56.musicplayer.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import com.missionbreak56.musicplayer.R
import com.missionbreak56.musicplayer.data.MusicRepository
import com.missionbreak56.musicplayer.data.Prefs
import com.missionbreak56.musicplayer.databinding.ActivityPlayerBinding
import com.missionbreak56.musicplayer.playback.PlayerConnection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private lateinit var connection: PlayerConnection
    private var controller: MediaController? = null

    private val handler = Handler(Looper.getMainLooper())
    private var userSeeking = false

    private val progressTicker = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, PROGRESS_INTERVAL_MS)
        }
    }

    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = refreshUi()
        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) = refreshUi()
        override fun onIsPlayingChanged(isPlaying: Boolean) = refreshUi()
        override fun onPlaybackStateChanged(playbackState: Int) = refreshUi()
        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) = refreshUi()
        override fun onRepeatModeChanged(repeatMode: Int) = refreshUi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val songId = intent.getLongExtra(EXTRA_SONG_ID, -1L)
        if (songId <= 0L) {
            finish()
            return
        }

        binding.btnBack.setOnClickListener { finish() }
        setupControls()

        connection = PlayerConnection(this) { c ->
            controller = c
            c.addListener(listener)
            if (c.mediaItemCount > 0 && c.currentMediaItem?.mediaId == songId.toString()) {
                // Same song is already loaded (e.g. opened from the mini player): keep playing.
                refreshUi()
            } else {
                startQueue(c, songId)
            }
        }
        connection.connect()
    }

    override fun onStart() {
        super.onStart()
        handler.post(progressTicker)
    }

    override fun onStop() {
        handler.removeCallbacks(progressTicker)
        super.onStop()
    }

    private fun setupControls() {
        binding.btnFavorite.setOnClickListener {
            val id = controller?.currentMediaItem?.mediaId?.toLongOrNull()
                ?: return@setOnClickListener
            val fav = Prefs.toggleFavorite(id)
            refreshUi()
            Toast.makeText(
                this,
                if (fav) R.string.added_to_favorites else R.string.removed_from_favorites,
                Toast.LENGTH_SHORT
            ).show()
        }

        binding.btnPlayPause.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            if (c.isPlaying) c.pause() else c.play()
        }
        binding.btnPrev.setOnClickListener { controller?.seekToPreviousMediaItem() }
        binding.btnNext.setOnClickListener { controller?.seekToNextMediaItem() }

        binding.btnShuffle.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            c.shuffleModeEnabled = !c.shuffleModeEnabled
        }
        binding.btnRepeat.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            c.repeatMode = when (c.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) binding.textPosition.text = formatDuration(progress.toLong())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                userSeeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                userSeeking = false
                controller?.seekTo(seekBar.progress.toLong())
            }
        })
    }

    private fun startQueue(c: MediaController, songId: Long) {
        lifecycleScope.launch {
            val songs = withContext(Dispatchers.IO) { MusicRepository.loadSongs(this@PlayerActivity) }
            if (songs.isEmpty()) {
                Toast.makeText(this@PlayerActivity, R.string.no_songs, Toast.LENGTH_SHORT).show()
                return@launch
            }
            val index = songs.indexOfFirst { it.id == songId }.coerceAtLeast(0)
            val items = songs.map { song ->
                MediaItem.Builder()
                    .setMediaId(song.id.toString())
                    .setUri(song.uri)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(song.displayTitle)
                            .setArtist(song.displayArtist)
                            .setAlbumTitle(song.displayAlbum)
                            .setIsBrowsable(false)
                            .setIsPlayable(true)
                            .build()
                    )
                    .build()
            }
            c.setMediaItems(items, index, 0L)
            c.prepare()
            c.play()
            refreshUi()
        }
    }

    private fun refreshUi() {
        val c = controller ?: return
        val item = c.currentMediaItem
        binding.textTitle.text = item?.mediaMetadata?.title ?: getString(R.string.unknown_title)
        binding.textArtist.text = item?.mediaMetadata?.artist ?: getString(R.string.unknown_artist)

        val id = item?.mediaId?.toLongOrNull()
        binding.btnFavorite.setImageResource(
            if (id != null && Prefs.isFavorite(id)) R.drawable.ic_favorite
            else R.drawable.ic_favorite_border
        )
        binding.btnPlayPause.setImageResource(
            if (c.isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        )

        setToggleState(binding.btnShuffle, c.shuffleModeEnabled)
        binding.btnRepeat.setImageResource(
            if (c.repeatMode == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one
            else R.drawable.ic_repeat
        )
        setToggleState(binding.btnRepeat, c.repeatMode != Player.REPEAT_MODE_OFF)

        updateProgress()
    }

    /** Active toggles are tinted with the brand color; inactive ones are dimmed. */
    private fun setToggleState(button: ImageButton, active: Boolean) {
        if (active) {
            button.setColorFilter(ContextCompat.getColor(this, R.color.brand_main))
            button.alpha = 1f
        } else {
            button.clearColorFilter()
            button.alpha = 0.5f
        }
    }

    private fun updateProgress() {
        val c = controller ?: return
        if (userSeeking) return
        // C.TIME_UNSET is negative, so coerceAtLeast also covers "duration not known yet".
        val duration = c.duration.coerceAtLeast(0L)
        val position = c.currentPosition.coerceIn(0L, duration)
        binding.seekBar.max = duration.toInt().coerceAtLeast(1)
        binding.seekBar.progress = position.toInt()
        binding.textPosition.text = formatDuration(position)
        binding.textDuration.text = formatDuration(duration)
    }

    override fun onDestroy() {
        handler.removeCallbacks(progressTicker)
        controller?.removeListener(listener)
        if (::connection.isInitialized) connection.release()
        controller = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_SONG_ID = "extra_song_id"
        private const val PROGRESS_INTERVAL_MS = 500L
    }
}
