package com.missionbreak56.musicplayer.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.missionbreak56.musicplayer.R
import com.missionbreak56.musicplayer.data.Song
import com.missionbreak56.musicplayer.databinding.ItemSongBinding

class SongAdapter(
    private val onSongClick: (Int) -> Unit
) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    private val items = ArrayList<Song>()
    private var playingId: Long? = null

    fun submit(list: List<Song>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    /** Highlights the row of the song that is currently loaded in the player. */
    fun setPlayingId(id: Long?) {
        if (playingId != id) {
            playingId = id
            notifyDataSetChanged()
        }
    }

    fun songAt(position: Int): Song? = items.getOrNull(position)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val binding = ItemSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SongViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class SongViewHolder(private val binding: ItemSongBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(song: Song) {
            val isPlaying = song.id == playingId
            val titleColor = if (isPlaying) R.color.brand_content else R.color.content_main

            binding.textTitle.text = song.displayTitle
            binding.textTitle.setTextColor(ContextCompat.getColor(binding.root.context, titleColor))
            binding.textSubtitle.text = "${song.displayArtist} • ${song.displayAlbum}"
            binding.textDuration.text = formatDuration(song.durationMs)
            binding.iconPlaying.visibility = if (isPlaying) View.VISIBLE else View.GONE
            binding.root.setOnClickListener {
                val pos = bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onSongClick(pos)
            }
        }
    }
}
